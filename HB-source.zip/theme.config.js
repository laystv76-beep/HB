/** @type {const} */
const themeColors = {
  primary: { light: '#176B45', dark: '#74C69D' },
  background: { light: '#F7FAF7', dark: '#101C16' },
  surface: { light: '#FFFFFF', dark: '#18271F' },
  foreground: { light: '#173024', dark: '#F1F8F3' },
  muted: { light: '#708178', dark: '#A8B9AF' },
  border: { light: '#E1EBE3', dark: '#30483A' },
  success: { light: '#2E8B57', dark: '#74C69D' },
  warning: { light: '#D7A62A', dark: '#F4D06F' },
  error: { light: '#C24141', dark: '#F28B8B' },
};

module.exports = { themeColors };
