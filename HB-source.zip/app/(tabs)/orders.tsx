import { MaterialIcons } from "@expo/vector-icons";
import { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Linking,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { formatPrice } from "@/lib/products";
import { trpc } from "@/lib/trpc";
import { useColors } from "@/hooks/use-colors";

type Status = "pending" | "confirmed" | "out_for_delivery" | "delivered" | "cancelled";
type Filter = "all" | Status;

const statusLabel: Record<Status, string> = {
  pending: "جديد",
  confirmed: "تم التأكيد",
  out_for_delivery: "قيد التوصيل",
  delivered: "تم التسليم",
  cancelled: "ملغى",
};

const statusColor: Record<Status, { bg: string; text: string }> = {
  pending: { bg: "#FFF4D6", text: "#8C6B1D" },
  confirmed: { bg: "#E8F4EA", text: "#176B45" },
  out_for_delivery: { bg: "#EAF2FF", text: "#2F5C9A" },
  delivered: { bg: "#E8F4EA", text: "#176B45" },
  cancelled: { bg: "#FDECEC", text: "#C24141" },
};

const nextStatus: Partial<Record<Status, Status>> = {
  pending: "confirmed",
  confirmed: "out_for_delivery",
  out_for_delivery: "delivered",
};

export default function OrdersScreen() {
  const colors = useColors();
  const [filter, setFilter] = useState<Filter>("all");
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const ordersQuery = trpc.orders.list.useQuery(undefined, { refetchInterval: 15_000, refetchOnReconnect: true });
  const updateOrderStatus = trpc.orders.updateStatus.useMutation();

  const orders = ordersQuery.data ?? [];
  const filteredOrders = useMemo(
    () => filter === "all" ? orders : orders.filter((order) => order.status === filter),
    [filter, orders],
  );
  const selectedOrder = orders.find((order) => order.id === selectedOrderId) ?? null;

  const refresh = async () => {
    setRefreshing(true);
    await ordersQuery.refetch();
    setRefreshing(false);
  };

  const advanceOrder = async (id: number, status: string) => {
    const next = nextStatus[status as Status];
    if (!next) return;
    try {
      await updateOrderStatus.mutateAsync({ id, status: next });
      await ordersQuery.refetch();
    } catch {
      Alert.alert("تعذر تحديث الطلب", "تحقق من اتصال الإنترنت ثم حاول مجدداً.");
    }
  };

  const openWhatsApp = async (phone: string) => {
    const normalized = phone.replace(/[^\d]/g, "");
    const url = `https://wa.me/${normalized}`;
    try {
      await Linking.openURL(url);
    } catch {
      Alert.alert("تعذر فتح واتساب", "تأكد من تثبيت واتساب على الجهاز.");
    }
  };

  const renderOrder = ({ item: order }: { item: (typeof orders)[number] }) => {
    const status = (order.status in statusLabel ? order.status : "pending") as Status;
    const colorsForStatus = statusColor[status];
    return (
      <Pressable
        onPress={() => setSelectedOrderId(order.id)}
        style={({ pressed }) => [
          { marginBottom: 10, borderRadius: 18, backgroundColor: colors.surface, borderWidth: 1, borderColor: status === "pending" ? "#F4C95D" : colors.border, padding: 14 },
          pressed && { opacity: 0.78 },
        ]}
      >
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <View style={{ borderRadius: 9, backgroundColor: colorsForStatus.bg, paddingHorizontal: 9, paddingVertical: 5 }}>
            <Text style={{ color: colorsForStatus.text, fontSize: 11, fontWeight: "900" }}>{statusLabel[status]}</Text>
          </View>
          <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: "900" }}>طلب #{order.id}</Text>
        </View>
        <Text style={{ marginTop: 9, color: colors.muted, fontSize: 12, textAlign: "right" }}>الهاتف: {order.customerPhone}</Text>
        <Text numberOfLines={2} style={{ marginTop: 4, color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: "right" }}>العنوان: {order.deliveryAddress}</Text>
        <View style={{ marginTop: 9, borderRadius: 12, backgroundColor: colors.background, padding: 10 }}>
          <Text style={{ marginBottom: 4, color: colors.foreground, fontSize: 12, fontWeight: "900", textAlign: "right" }}>الأصناف المطلوبة</Text>
          {order.items?.length ? order.items.map((item) => (
            <Text key={item.id} numberOfLines={1} style={{ marginTop: 3, color: colors.muted, fontSize: 11, textAlign: "right" }}>{item.quantity} × {item.productName} · {formatPrice(item.subtotal)}</Text>
          )) : <Text style={{ color: colors.muted, fontSize: 11, textAlign: "right" }}>اضغط لعرض التفاصيل</Text>}
        </View>
        <View style={{ marginTop: 10, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
          <Text style={{ color: "#176B45", fontSize: 16, fontWeight: "900" }}>{formatPrice(order.total)}</Text>
          <Text style={{ color: colors.muted, fontSize: 10 }}>نقداً عند الاستلام · اضغط للتفاصيل</Text>
        </View>
        <View style={{ marginTop: 10, flexDirection: "row", gap: 8 }}>
          <Pressable onPress={() => void openWhatsApp(order.customerPhone)} style={({ pressed }) => [{ flex: 1, minHeight: 38, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, borderRadius: 10, backgroundColor: "#EAF6ED" }, pressed && { opacity: 0.75 }]}>
            <MaterialIcons name="phone" size={16} color="#176B45" />
            <Text style={{ color: "#176B45", fontSize: 11, fontWeight: "900" }}>واتساب</Text>
          </Pressable>
          {nextStatus[status] && <Pressable onPress={() => void advanceOrder(order.id, status)} style={({ pressed }) => [{ flex: 1.5, minHeight: 38, alignItems: "center", justifyContent: "center", borderRadius: 10, backgroundColor: "#176B45" }, pressed && { opacity: 0.8 }]}>
            <Text style={{ color: "#FFFFFF", fontSize: 11, fontWeight: "900" }}>{status === "pending" ? "تأكيد الطلب" : status === "confirmed" ? "إرساله للتوصيل" : "تأكيد التسليم"}</Text>
          </Pressable>}
        </View>
      </Pressable>
    );
  };

  return (
    <ScreenContainer className="px-4" containerClassName="bg-background">
      <FlatList
        data={filteredOrders}
        keyExtractor={(item) => String(item.id)}
        renderItem={renderOrder}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void refresh()} tintColor="#176B45" colors={["#176B45"]} />}
        contentContainerStyle={{ paddingTop: 16, paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={<View>
          <View style={{ marginBottom: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
            <View style={{ flex: 1, paddingLeft: 12 }}><Text style={{ color: colors.muted, fontSize: 13, textAlign: "right" }}>لوحة الاستقبال</Text><Text style={{ marginTop: 3, color: colors.foreground, fontSize: 27, fontWeight: "900", textAlign: "right" }}>طلبات الزبائن</Text></View>
            <View style={{ width: 54, height: 54, borderRadius: 18, alignItems: "center", justifyContent: "center", backgroundColor: "#F4C95D" }}><MaterialIcons name="receipt-long" size={28} color="#59451A" /></View>
          </View>
          <View style={{ marginBottom: 14, borderRadius: 16, backgroundColor: "#EAF6ED", padding: 13 }}><Text style={{ color: "#176B45", fontSize: 12, fontWeight: "800", textAlign: "right" }}>تحديث تلقائي كل 15 ثانية</Text><Text style={{ marginTop: 5, color: "#437253", fontSize: 11, lineHeight: 17, textAlign: "right" }}>هذا التطبيق مخصص لاستقبال الطلبات ومتابعتها فقط. لا يحتوي على تعديل المنتجات أو الأسعار.</Text></View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ flexDirection: "row-reverse", gap: 7, paddingBottom: 14 }}>
            {(["all", "pending", "confirmed", "out_for_delivery", "delivered", "cancelled"] as Filter[]).map((value) => {
              const label = value === "all" ? "الكل" : statusLabel[value];
              const count = value === "all" ? orders.length : orders.filter((order) => order.status === value).length;
              const active = filter === value;
              return <Pressable key={value} onPress={() => setFilter(value)} style={({ pressed }) => [{ borderRadius: 12, backgroundColor: active ? "#176B45" : colors.surface, borderWidth: 1, borderColor: active ? "#176B45" : colors.border, paddingHorizontal: 12, paddingVertical: 8 }, pressed && { opacity: 0.75 }]}><Text style={{ color: active ? "#FFFFFF" : colors.foreground, fontSize: 11, fontWeight: "800" }}>{label} ({count})</Text></Pressable>;
            })}
          </ScrollView>
          {ordersQuery.isLoading && <ActivityIndicator color="#176B45" style={{ marginBottom: 12 }} />}
          {!ordersQuery.isLoading && filter === "all" && orders.length > 0 && <Text style={{ marginBottom: 10, color: colors.muted, fontSize: 12, textAlign: "right" }}>{orders.length} طلب إجمالاً</Text>}
        </View>}
        ListEmptyComponent={<View style={{ alignItems: "center", borderRadius: 18, backgroundColor: colors.surface, padding: 28 }}><MaterialIcons name="inbox" size={44} color={colors.muted} /><Text style={{ marginTop: 10, color: colors.muted, fontSize: 13 }}>{filter === "all" ? "لا توجد طلبات حتى الآن" : "لا توجد طلبات بهذه الحالة"}</Text></View>}
      />

      <View />
      {selectedOrder && <View style={{ position: "absolute", top: 0, right: 0, bottom: 0, left: 0, justifyContent: "flex-end", backgroundColor: "rgba(13,36,24,0.35)" }}>
        <View style={{ maxHeight: "88%", borderTopLeftRadius: 28, borderTopRightRadius: 28, backgroundColor: colors.background, padding: 20 }}>
          <View style={{ marginBottom: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}><Pressable onPress={() => setSelectedOrderId(null)} style={({ pressed }) => [{ width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface }, pressed && { opacity: 0.65 }]}><MaterialIcons name="close" size={20} color={colors.foreground} /></Pressable><Text style={{ color: colors.foreground, fontSize: 20, fontWeight: "900" }}>تفاصيل الطلب #{selectedOrder.id}</Text></View>
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={{ marginBottom: 14, borderRadius: 16, backgroundColor: "#EAF6ED", padding: 14 }}><Text style={{ color: "#176B45", fontSize: 13, fontWeight: "800", textAlign: "right" }}>الدفع نقداً عند الاستلام · {statusLabel[selectedOrder.status as Status] ?? selectedOrder.status}</Text><Text style={{ marginTop: 7, color: colors.foreground, fontSize: 13, textAlign: "right" }}>رقم التواصل: {selectedOrder.customerPhone}</Text><Text style={{ marginTop: 5, color: colors.foreground, fontSize: 13, lineHeight: 19, textAlign: "right" }}>العنوان: {selectedOrder.deliveryAddress}</Text>{selectedOrder.locationNote && <Text style={{ marginTop: 5, color: colors.muted, fontSize: 12, lineHeight: 18, textAlign: "right" }}>ملاحظة الموقع: {selectedOrder.locationNote}</Text>}<Text style={{ marginTop: 8, color: "#176B45", fontSize: 16, fontWeight: "900", textAlign: "right" }}>الإجمالي: {formatPrice(selectedOrder.total)}</Text></View>
            <Text style={{ marginBottom: 8, color: colors.foreground, fontSize: 15, fontWeight: "900", textAlign: "right" }}>المواد المطلوبة</Text>
            {selectedOrder.items?.map((item) => <View key={item.id} style={{ marginBottom: 7, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 12, backgroundColor: colors.surface, padding: 11 }}><Text style={{ color: "#176B45", fontSize: 13, fontWeight: "800" }}>{item.quantity} × {formatPrice(item.unitPrice)}</Text><Text style={{ color: colors.foreground, fontSize: 13, fontWeight: "700", textAlign: "right" }}>{item.productName} ({item.unit})</Text></View>)}
            <Pressable onPress={() => void openWhatsApp(selectedOrder.customerPhone)} style={({ pressed }) => [{ marginTop: 8, minHeight: 48, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderRadius: 14, backgroundColor: "#176B45" }, pressed && { opacity: 0.8 }]}><MaterialIcons name="phone" size={19} color="#FFFFFF" /><Text style={{ color: "#FFFFFF", fontSize: 14, fontWeight: "900" }}>التواصل مع الزبون عبر واتساب</Text></Pressable>
          </ScrollView>
        </View>
      </View>}
    </ScreenContainer>
  );
}

// Keep the status union close to the server contract while allowing the list to render safely.
