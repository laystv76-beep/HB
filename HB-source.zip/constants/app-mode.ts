export const CUSTOMER_MODE = process.env.EXPO_PUBLIC_CUSTOMER_MODE === "true";
export const ORDERS_MODE = process.env.EXPO_PUBLIC_ORDERS_MODE === "true";
